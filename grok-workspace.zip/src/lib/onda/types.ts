import type { GuidelineKey } from "./guidelines";

export type Profile = {
  userId: string;
  handle: string;
  displayName: string;
  bio: string;
  avatarHue: number;
  avatarUrl: string | null;
  verified: boolean;
  isOfficial: boolean;
  isAdmin: boolean;
  restricted: boolean;
  warningCount: number;
  createdAt: string;
  followerCount: number;
  followingCount: number;
  videoCount: number;
};

export type VideoCard = {
  id: string;
  userId: string;
  caption: string;
  videoUrl: string;
  posterUrl: string | null;
  soundName: string;
  restricted: boolean;
  removed: boolean;
  viewCount: number;
  likeCount: number;
  commentCount: number;
  liked: boolean;
  createdAt: string;
  author: {
    userId: string;
    handle: string;
    displayName: string;
    avatarHue: number;
    avatarUrl: string | null;
    verified: boolean;
    isOfficial: boolean;
  };
};

export type Comment = {
  id: string;
  videoId: string;
  body: string;
  createdAt: string;
  author: {
    userId: string;
    handle: string;
    displayName: string;
    avatarHue: number;
    verified: boolean;
    isOfficial: boolean;
  };
};

export type Report = {
  id: string;
  videoId: string;
  reporterId: string;
  reason: string;
  details: string;
  status: "open" | "reviewing" | "actioned" | "dismissed";
  createdAt: string;
};

export type ReportDetail = Report & {
  video: VideoCard;
  reporterHandle: string;
  reporterName: string;
  aiReview: AiReview | null;
};

export type AiReview = {
  id: string;
  reportId: string;
  videoId: string;
  verdict: "violation" | "likely" | "clean" | "inconclusive";
  summary: string;
  guidelinesHit: GuidelineKey[];
  recommended: "remove" | "restrict" | "warn" | "dismiss";
  confidence: number;
  createdAt: string;
};

export type Notification = {
  id: string;
  kind: string;
  title: string;
  body: string;
  href: string | null;
  read: boolean;
  createdAt: string;
};

export type ModerationLog = {
  id: string;
  action: string;
  note: string;
  targetUserId: string | null;
  videoId: string | null;
  reportId: string | null;
  createdAt: string;
};
