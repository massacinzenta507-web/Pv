export const APP_NAME = "ONDA";
export const APP_TAGLINE = "A próxima onda de vídeos curtos";

export const OFFICIAL_EMAIL = "oficial@onda.app";
export const OFFICIAL_PASSWORD = "OndaOficial#2026";
export const OFFICIAL_HANDLE = "onda";
export const OFFICIAL_DISPLAY = "ONDA";
