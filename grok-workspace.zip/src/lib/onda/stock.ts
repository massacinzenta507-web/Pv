export type StockClip = {
  id: string;
  title: string;
  url: string;
  sound: string;
};

/** Reliable public sample clips (cover-cropped to 9:16 in the player). */
export const STOCK_CLIPS: StockClip[] = [
  {
    id: "joyrides",
    title: "Pista aberta",
    url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerJoyrides.mp4",
    sound: "Som original · pista",
  },
  {
    id: "blazes",
    title: "Chama alta",
    url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4",
    sound: "Som original · blaze",
  },
  {
    id: "escapes",
    title: "Fuga noturna",
    url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerEscapes.mp4",
    sound: "Som original · escape",
  },
  {
    id: "fun",
    title: "Diversão",
    url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerFun.mp4",
    sound: "Som original · fun",
  },
  {
    id: "meltdown",
    title: "Derretendo",
    url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerMeltdowns.mp4",
    sound: "Som original · melt",
  },
  {
    id: "subaru",
    title: "Terra e asfalto",
    url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/SubaruOutbackOnStreetAndDirt.mp4",
    sound: "Som original · trilha",
  },
  {
    id: "bullrun",
    title: "Corrida",
    url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/WeAreGoingOnBullrun.mp4",
    sound: "Som original · run",
  },
  {
    id: "gti",
    title: "Motor vivo",
    url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/VolkswagenGTIReview.mp4",
    sound: "Som original · motor",
  },
  {
    id: "bunny",
    title: "Bosque",
    url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4",
    sound: "Som original · bosque",
  },
  {
    id: "elephants",
    title: "Sonho",
    url: "https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ElephantsDream.mp4",
    sound: "Som original · sonho",
  },
];
