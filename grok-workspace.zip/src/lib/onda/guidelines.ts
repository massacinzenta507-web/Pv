export const GUIDELINE_KEYS = [
  "violence",
  "harassment",
  "sexual",
  "hate",
  "minors",
  "spam",
  "scams",
  "misinfo",
  "dangerous",
  "ip",
] as const;

export type GuidelineKey = (typeof GUIDELINE_KEYS)[number];

export const GUIDELINES: {
  key: GuidelineKey;
  title: string;
  summary: string;
}[] = [
  {
    key: "violence",
    title: "Violência gráfica",
    summary:
      "Não permitimos conteúdo que mostre violência extrema, tortura ou incentivo a crimes violentos.",
  },
  {
    key: "harassment",
    title: "Assédio e bullying",
    summary:
      "Ataques pessoais, doxxing, perseguição e humilhação dirigida a pessoas reais são proibidos.",
  },
  {
    key: "sexual",
    title: "Nudez e conteúdo sexual",
    summary:
      "Conteúdo sexual explícito, nudez pornográfica e exploração sexual não são permitidos.",
  },
  {
    key: "hate",
    title: "Discurso de ódio",
    summary:
      "Ataques a pessoas por raça, etnia, religião, gênero, orientação, deficiência ou nacionalidade.",
  },
  {
    key: "minors",
    title: "Proteção de menores",
    summary:
      "Qualquer conteúdo sexual, exploratório ou perigoso envolvendo menores é removido imediatamente.",
  },
  {
    key: "spam",
    title: "Spam e engajamento falso",
    summary:
      "Repetições em massa, links enganosos, fazendas de views e contas automatizadas.",
  },
  {
    key: "scams",
    title: "Golpes e fraude",
    summary:
      "Esquemas financeiros, phishing, vendas falsas e pedidos de dados pessoais.",
  },
  {
    key: "misinfo",
    title: "Desinformação prejudicial",
    summary:
      "Mentiras que possam causar dano real — saúde, eleições, emergências — com intenção de enganar.",
  },
  {
    key: "dangerous",
    title: "Desafios e atos perigosos",
    summary:
      "Incentivo a automutilação, uso de drogas, desafios que possam ferir o criador ou outras pessoas.",
  },
  {
    key: "ip",
    title: "Propriedade intelectual",
    summary:
      "Uso não autorizado de obras, marcas ou conteúdos de terceiros de forma comercial ou enganosa.",
  },
];

export const REPORT_REASONS: { id: string; label: string; guideline: GuidelineKey }[] =
  [
    { id: "violence", label: "Violência ou conteúdo gráfico", guideline: "violence" },
    { id: "harassment", label: "Assédio ou bullying", guideline: "harassment" },
    { id: "sexual", label: "Nudez ou conteúdo sexual", guideline: "sexual" },
    { id: "hate", label: "Discurso de ódio", guideline: "hate" },
    { id: "minors", label: "Envolve menores de forma inadequada", guideline: "minors" },
    { id: "spam", label: "Spam ou enganoso", guideline: "spam" },
    { id: "scams", label: "Golpe ou fraude", guideline: "scams" },
    { id: "misinfo", label: "Desinformação prejudicial", guideline: "misinfo" },
    { id: "dangerous", label: "Desafio ou ato perigoso", guideline: "dangerous" },
    { id: "ip", label: "Uso indevido de conteúdo", guideline: "ip" },
    { id: "other", label: "Outro", guideline: "spam" },
  ];

export function guidelinesForPrompt(): string {
  return GUIDELINES.map((g) => `- ${g.key}: ${g.title}. ${g.summary}`).join("\n");
}
