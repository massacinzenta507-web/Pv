import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import { guidelinesForPrompt, GUIDELINE_KEYS } from "@/lib/onda/guidelines";
import type { AiReview } from "@/lib/onda/types";
import { nid } from "@/lib/utils";
import { mapAiReview } from "./map";
import { requireAdmin } from "./profiles";

type ModelJson = {
  verdict?: string;
  confidence?: number;
  summary?: string;
  guidelines_hit?: string[];
  recommended_action?: string;
};

export const analyzeReport = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((reportId: string) => reportId)
  .handler(async ({ context, data: reportId }): Promise<AiReview> => {
    await requireAdmin(context.userId);
    const sql = await getSql();

    const cached = await sql`select * from ai_reviews where report_id = ${reportId} limit 1`;
    if (cached[0]) return mapAiReview(cached[0]);

    const rows = await sql`
      select r.id, r.reason, r.details, r.video_id,
             v.caption, v.sound_name, v.video_url,
             p.handle, p.display_name, p.bio
      from reports r
      join videos v on v.id = r.video_id
      join profiles p on p.user_id = v.user_id
      where r.id = ${reportId}
      limit 1
    `;
    const row = rows[0];
    if (!row) throw new Error("Denúncia não encontrada");

    await sql`update reports set status = 'reviewing' where id = ${reportId} and status = 'open'`;

    const apiKey = process.env.XAI_API_KEY;
    if (!apiKey) {
      const fallback = await persistReview(sql, reportId, String(row.video_id), {
        verdict: "inconclusive",
        confidence: 0,
        summary:
          "A análise por IA não está disponível neste ambiente. Revise o vídeo manualmente pelas diretrizes da ONDA.",
        guidelines_hit: [],
        recommended_action: "dismiss",
      });
      return fallback;
    }

    const prompt = `Você é o analista de confiança da ONDA, um app brasileiro de vídeos curtos.
Avalie se o vídeo denunciado viola as diretrizes. Você NÃO vê o arquivo de vídeo — apenas metadados (legenda, som, handle, motivo da denúncia). Seja conservador: sem evidência clara, use "inconclusive" ou "clean". Nunca invente o que acontece na imagem.

Diretrizes:
${guidelinesForPrompt()}

Denúncia:
- Motivo escolhido: ${row.reason}
- Relato: ${row.details || "(sem detalhes)"}
- Criador: @${row.handle} (${row.display_name})
- Bio: ${row.bio || "(vazia)"}
- Legenda do vídeo: ${row.caption}
- Som: ${row.sound_name}

Responda SOMENTE um JSON válido, sem markdown:
{
  "verdict": "violation" | "likely" | "clean" | "inconclusive",
  "confidence": 0.0-1.0,
  "summary": "2 a 4 frases em português, objetivas, para o moderador humano",
  "guidelines_hit": ["violence"|"harassment"|"sexual"|"hate"|"minors"|"spam"|"scams"|"misinfo"|"dangerous"|"ip"],
  "recommended_action": "remove" | "restrict" | "warn" | "dismiss"
}`;

    const res = await fetch("https://api.x.ai/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        Authorization: `Bearer ${apiKey}`,
      },
      body: JSON.stringify({
        model: "grok-4.5",
        max_tokens: 700,
        temperature: 0.2,
        messages: [{ role: "user", content: prompt }],
      }),
    });

    if (!res.ok) {
      return persistReview(sql, reportId, String(row.video_id), {
        verdict: "inconclusive",
        confidence: 0,
        summary: `A IA retornou erro ${res.status}. Faça a revisão manual.`,
        guidelines_hit: [],
        recommended_action: "dismiss",
      });
    }

    const body = (await res.json()) as {
      choices?: { message?: { content?: string } }[];
    };
    const text = body.choices?.[0]?.message?.content ?? "";
    const parsed = parseModelJson(text);
    return persistReview(sql, reportId, String(row.video_id), parsed);
  });

function parseModelJson(text: string): ModelJson {
  const match = text.match(/\{[\s\S]*\}/);
  if (!match) return { verdict: "inconclusive", summary: text.slice(0, 500) };
  try {
    return JSON.parse(match[0]) as ModelJson;
  } catch {
    return { verdict: "inconclusive", summary: text.slice(0, 500) };
  }
}

async function persistReview(
  sql: Awaited<ReturnType<typeof getSql>>,
  reportId: string,
  videoId: string,
  parsed: ModelJson,
): Promise<AiReview> {
  const verdict = ["violation", "likely", "clean", "inconclusive"].includes(
    parsed.verdict ?? "",
  )
    ? parsed.verdict!
    : "inconclusive";
  const recommended = ["remove", "restrict", "warn", "dismiss"].includes(
    parsed.recommended_action ?? "",
  )
    ? parsed.recommended_action!
    : "dismiss";
  const hit = (parsed.guidelines_hit ?? []).filter((k) =>
    (GUIDELINE_KEYS as readonly string[]).includes(k),
  );
  const confidence = Math.max(0, Math.min(1, Number(parsed.confidence) || 0));
  const summary =
    (parsed.summary ?? "Sem resumo.").toString().slice(0, 1200) || "Sem resumo.";
  const id = nid();
  await sql`
    insert into ai_reviews (
      id, report_id, video_id, verdict, summary, guidelines_hit, recommended, confidence
    ) values (
      ${id}, ${reportId}, ${videoId}, ${verdict}, ${summary},
      ${JSON.stringify(hit)}, ${recommended}, ${String(confidence)}
    )
    on conflict (report_id) do nothing
  `;
  const rows = await sql`select * from ai_reviews where report_id = ${reportId} limit 1`;
  return mapAiReview(rows[0]!);
}
