import type { AiReview, Profile, VideoCard } from "@/lib/onda/types";
import type { GuidelineKey } from "@/lib/onda/guidelines";

export function asIso(v: unknown): string {
  if (typeof v === "string") {
    const d = new Date(v);
    return Number.isNaN(d.getTime()) ? v : d.toISOString();
  }
  if (v instanceof Date) return v.toISOString();
  return new Date().toISOString();
}

export function asBool(v: unknown): boolean {
  return v === true || v === "t" || v === "true" || v === 1 || v === "1";
}

export function asNum(v: unknown): number {
  const n = Number(v);
  return Number.isFinite(n) ? n : 0;
}

export function asStr(v: unknown, fallback = ""): string {
  return v == null ? fallback : String(v);
}

type ProfileRow = {
  user_id: unknown;
  handle: unknown;
  display_name: unknown;
  bio: unknown;
  avatar_hue: unknown;
  avatar_url: unknown;
  verified: unknown;
  is_official: unknown;
  is_admin: unknown;
  restricted: unknown;
  warning_count: unknown;
  created_at: unknown;
  follower_count?: unknown;
  following_count?: unknown;
  video_count?: unknown;
};

export function mapProfile(row: ProfileRow): Profile {
  return {
    userId: asStr(row.user_id),
    handle: asStr(row.handle),
    displayName: asStr(row.display_name),
    bio: asStr(row.bio),
    avatarHue: asNum(row.avatar_hue) || 168,
    avatarUrl: row.avatar_url ? asStr(row.avatar_url) : null,
    verified: asBool(row.verified),
    isOfficial: asBool(row.is_official),
    isAdmin: asBool(row.is_admin),
    restricted: asBool(row.restricted),
    warningCount: asNum(row.warning_count),
    createdAt: asIso(row.created_at),
    followerCount: asNum(row.follower_count),
    followingCount: asNum(row.following_count),
    videoCount: asNum(row.video_count),
  };
}

type VideoRow = {
  id: unknown;
  user_id: unknown;
  caption: unknown;
  video_url: unknown;
  poster_url: unknown;
  sound_name: unknown;
  restricted: unknown;
  removed: unknown;
  view_count: unknown;
  created_at: unknown;
  like_count?: unknown;
  comment_count?: unknown;
  handle: unknown;
  display_name: unknown;
  avatar_hue: unknown;
  avatar_url?: unknown;
  verified: unknown;
  is_official: unknown;
};

export function mapVideo(row: VideoRow, liked: boolean): VideoCard {
  return {
    id: asStr(row.id),
    userId: asStr(row.user_id),
    caption: asStr(row.caption),
    videoUrl: asStr(row.video_url),
    posterUrl: row.poster_url ? asStr(row.poster_url) : null,
    soundName: asStr(row.sound_name, "Som original"),
    restricted: asBool(row.restricted),
    removed: asBool(row.removed),
    viewCount: asNum(row.view_count),
    likeCount: asNum(row.like_count),
    commentCount: asNum(row.comment_count),
    liked,
    createdAt: asIso(row.created_at),
    author: {
      userId: asStr(row.user_id),
      handle: asStr(row.handle),
      displayName: asStr(row.display_name),
      avatarHue: asNum(row.avatar_hue) || 168,
      avatarUrl: row.avatar_url ? asStr(row.avatar_url) : null,
      verified: asBool(row.verified),
      isOfficial: asBool(row.is_official),
    },
  };
}

export const VIDEO_SELECT = `
  v.id, v.user_id, v.caption, v.video_url, v.poster_url, v.sound_name,
  v.restricted, v.removed, v.view_count, v.created_at,
  (select count(*)::int from likes l where l.video_id = v.id) as like_count,
  (select count(*)::int from comments c where c.video_id = v.id) as comment_count,
  p.handle, p.display_name, p.avatar_hue, p.avatar_url, p.verified, p.is_official
`;

export function mapAiReview(row: {
  id: unknown;
  report_id: unknown;
  video_id: unknown;
  verdict: unknown;
  summary: unknown;
  guidelines_hit: unknown;
  recommended: unknown;
  confidence: unknown;
  created_at: unknown;
}): AiReview {
  let guidelinesHit: GuidelineKey[] = [];
  try {
    const parsed = JSON.parse(asStr(row.guidelines_hit, "[]"));
    if (Array.isArray(parsed)) guidelinesHit = parsed as GuidelineKey[];
  } catch {
    guidelinesHit = [];
  }
  const verdict = asStr(row.verdict, "inconclusive") as AiReview["verdict"];
  const recommended = asStr(row.recommended, "dismiss") as AiReview["recommended"];
  return {
    id: asStr(row.id),
    reportId: asStr(row.report_id),
    videoId: asStr(row.video_id),
    verdict: ["violation", "likely", "clean", "inconclusive"].includes(verdict)
      ? verdict
      : "inconclusive",
    summary: asStr(row.summary),
    guidelinesHit,
    recommended: ["remove", "restrict", "warn", "dismiss"].includes(recommended)
      ? recommended
      : "dismiss",
    confidence: asNum(row.confidence),
    createdAt: asIso(row.created_at),
  };
}
