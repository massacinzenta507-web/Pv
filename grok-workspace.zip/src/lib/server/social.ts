import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import type { Comment, Notification } from "@/lib/onda/types";
import { nid } from "@/lib/utils";
import { asBool, asIso, asStr } from "./map";
import { loadProfileByUserId } from "./profiles";
import { ensureSeeded } from "./seed";

export const toggleLike = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((videoId: string) => videoId)
  .handler(async ({ context, data: videoId }) => {
    const sql = await getSql();
    const existing = await sql<{ user_id: string }>`
      select user_id from likes where user_id = ${context.userId} and video_id = ${videoId}
    `;
    if (existing[0]) {
      await sql`delete from likes where user_id = ${context.userId} and video_id = ${videoId}`;
      return { liked: false };
    }
    await sql`
      insert into likes (user_id, video_id) values (${context.userId}, ${videoId})
      on conflict do nothing
    `;
    return { liked: true };
  });

export const toggleFollow = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((targetId: string) => targetId)
  .handler(async ({ context, data: targetId }) => {
    if (targetId === context.userId) return { following: false };
    const sql = await getSql();
    const existing = await sql<{ follower_id: string }>`
      select follower_id from follows
      where follower_id = ${context.userId} and following_id = ${targetId}
    `;
    if (existing[0]) {
      await sql`
        delete from follows
        where follower_id = ${context.userId} and following_id = ${targetId}
      `;
      return { following: false };
    }
    await sql`
      insert into follows (follower_id, following_id)
      values (${context.userId}, ${targetId})
      on conflict do nothing
    `;
    const me = await loadProfileByUserId(context.userId);
    const target = await loadProfileByUserId(targetId);
    if (me && target) {
      await sql`
        insert into notifications (id, user_id, kind, title, body, href)
        values (
          ${nid()}, ${targetId}, ${"follow"},
          ${`${me.displayName} começou a seguir você`},
          ${`@${me.handle}`},
          ${`/u/${me.handle}`}
        )
      `;
    }
    return { following: true };
  });

export const listComments = createServerFn({ method: "GET" })
  .validator((videoId: string) => videoId)
  .handler(async ({ data: videoId }) => {
    await ensureSeeded();
    const sql = await getSql();
    const rows = await sql`
      select c.id, c.video_id, c.body, c.created_at,
             p.user_id, p.handle, p.display_name, p.avatar_hue, p.verified, p.is_official
      from comments c
      join profiles p on p.user_id = c.user_id
      where c.video_id = ${videoId}
      order by c.created_at desc
      limit 80
    `;
    return rows.map(
      (r): Comment => ({
        id: asStr(r.id),
        videoId: asStr(r.video_id),
        body: asStr(r.body),
        createdAt: asIso(r.created_at),
        author: {
          userId: asStr(r.user_id),
          handle: asStr(r.handle),
          displayName: asStr(r.display_name),
          avatarHue: Number(r.avatar_hue) || 168,
          verified: asBool(r.verified),
          isOfficial: asBool(r.is_official),
        },
      }),
    );
  });

export const addComment = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { videoId: string; body: string }) => ({
    videoId: input.videoId,
    body: input.body.trim().slice(0, 240),
  }))
  .handler(async ({ context, data }) => {
    if (!data.body) throw new Error("Escreva um comentário");
    const sql = await getSql();
    const id = nid();
    await sql`
      insert into comments (id, video_id, user_id, body)
      values (${id}, ${data.videoId}, ${context.userId}, ${data.body})
    `;
    const comments = await listComments({ data: data.videoId });
    return comments;
  });

export const listNotifications = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await ensureSeeded();
    const sql = await getSql();
    const rows = await sql`
      select id, kind, title, body, href, read, created_at
      from notifications
      where user_id = ${context.userId}
      order by created_at desc
      limit 40
    `;
    return rows.map(
      (r): Notification => ({
        id: asStr(r.id),
        kind: asStr(r.kind),
        title: asStr(r.title),
        body: asStr(r.body),
        href: r.href ? asStr(r.href) : null,
        read: asBool(r.read),
        createdAt: asIso(r.created_at),
      }),
    );
  });

export const markNotificationsRead = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    const sql = await getSql();
    await sql`update notifications set read = true where user_id = ${context.userId}`;
    return true;
  });
