import { getSql } from "@/lib/db";
import { STOCK_CLIPS } from "@/lib/onda/stock";
import {
  OFFICIAL_DISPLAY,
  OFFICIAL_EMAIL,
  OFFICIAL_HANDLE,
  OFFICIAL_PASSWORD,
} from "@/lib/onda/official";
import { nid } from "@/lib/utils";

const SEED_KEY = "onda_v1";

type Creator = {
  id: string;
  handle: string;
  name: string;
  bio: string;
  hue: number;
  verified?: boolean;
};

const CREATORS: Creator[] = [
  {
    id: "seed:luna",
    handle: "luna.moves",
    name: "Luna Alves",
    bio: "Dança, cidade e madrugada. SP.",
    hue: 168,
    verified: true,
  },
  {
    id: "seed:cafe",
    handle: "cafe.na.rua",
    name: "Café na Rua",
    bio: "Um espresso por esquina.",
    hue: 28,
  },
  {
    id: "seed:rio",
    handle: "rio.azul",
    name: "Rio Azul",
    bio: "Água, vento, fim de tarde.",
    hue: 200,
    verified: true,
  },
  {
    id: "seed:neon",
    handle: "noite.neon",
    name: "Noite Néon",
    bio: "A cidade depois das 23h.",
    hue: 312,
  },
  {
    id: "seed:cozinha",
    handle: "cozinha.rapida",
    name: "Cozinha Rápida",
    bio: "Receitas em 20 segundos.",
    hue: 42,
    verified: true,
  },
  {
    id: "seed:skate",
    handle: "skate.sp",
    name: "Skate SP",
    bio: "Pista, queda, de novo.",
    hue: 152,
  },
  {
    id: "seed:mar",
    handle: "som.do.mar",
    name: "Som do Mar",
    bio: "Ondas de verdade.",
    hue: 188,
  },
  {
    id: "seed:click",
    handle: "promo.relampago",
    name: "Promo Relâmpago",
    bio: "Ofertas. Sempre.",
    hue: 12,
  },
];

let chain: Promise<void> | null = null;

export async function ensureSeeded(): Promise<void> {
  if (!chain) {
    chain = seedOnce().finally(() => {
      /* keep chain so concurrent callers still await the same work */
    });
  }
  await chain;
}

async function seedOnce(): Promise<void> {
  const sql = await getSql();
  const existing = await sql<{ value: string }>`
    select value from seed_meta where key = ${SEED_KEY}
  `;
  if (existing[0]) return;

  const officialId = await ensureOfficialUser();

  await sql`
    insert into profiles (
      user_id, handle, display_name, bio, avatar_hue, verified,
      is_official, is_admin, restricted, warning_count
    ) values (
      ${officialId}, ${OFFICIAL_HANDLE}, ${OFFICIAL_DISPLAY},
      ${"Conta oficial da ONDA. Diretrizes, avisos e o que está bombando."},
      ${168}, ${true}, ${true}, ${true}, ${false}, ${0}
    )
    on conflict (user_id) do update set
      handle = excluded.handle,
      is_official = true,
      is_admin = true,
      verified = true
  `;

  for (const c of CREATORS) {
    await sql`
      insert into profiles (
        user_id, handle, display_name, bio, avatar_hue, verified,
        is_official, is_admin
      ) values (
        ${c.id}, ${c.handle}, ${c.name}, ${c.bio}, ${c.hue},
        ${c.verified ?? false}, ${false}, ${false}
      )
      on conflict (user_id) do nothing
    `;
  }

  const clip = (i: number) => STOCK_CLIPS[i % STOCK_CLIPS.length]!;

  type Vid = {
    id: string;
    user: string;
    caption: string;
    clip: number;
    sound?: string;
    views: number;
    likes: number;
  };

  const videos: Vid[] = [
    {
      id: "v-welcome",
      user: officialId,
      caption:
        "Bem-vindo à ONDA. Vídeos curtos, comunidade de verdade e moderação que não dorme. Desliza.",
      clip: 3,
      sound: "Hino ONDA · original",
      views: 128400,
      likes: 18420,
    },
    {
      id: "v-luna-1",
      user: "seed:luna",
      caption: "A coreografia que a avenida pediu. Ensaio no Minhocão, 1 take.",
      clip: 0,
      views: 84210,
      likes: 11203,
    },
    {
      id: "v-cafe-1",
      user: "seed:cafe",
      caption: "Pingado na calçada, 6 da manhã. São Paulo ainda boceja.",
      clip: 5,
      views: 22100,
      likes: 3102,
    },
    {
      id: "v-rio-1",
      user: "seed:rio",
      caption: "A cor que o Atlântico inventou hoje. Sem filtro.",
      clip: 8,
      views: 67340,
      likes: 9801,
    },
    {
      id: "v-neon-1",
      user: "seed:neon",
      caption: "Paulista depois da chuva. O asfalto vira espelho.",
      clip: 2,
      views: 41002,
      likes: 5600,
    },
    {
      id: "v-cook-1",
      user: "seed:cozinha",
      caption: "Molho de tomate em 20s. Alho, azeite, paciência nenhuma.",
      clip: 4,
      views: 155300,
      likes: 24011,
    },
    {
      id: "v-skate-1",
      user: "seed:skate",
      caption: "Tentativa 14. O 15 vai.",
      clip: 6,
      views: 19800,
      likes: 2704,
    },
    {
      id: "v-mar-1",
      user: "seed:mar",
      caption: "Fecha o olho. É só o mar.",
      clip: 1,
      views: 50220,
      likes: 7400,
    },
    {
      id: "v-spam-1",
      user: "seed:click",
      caption:
        "GANHE R$10.000 EM 5 MINUTOS!!! Clique no link da bio agora, último dia, não perca, 100% garantido.",
      clip: 7,
      views: 890,
      likes: 12,
    },
    {
      id: "v-danger-1",
      user: "seed:skate",
      caption:
        "Desafio da ponte: saltei sem rede. Se você é fraco nem tenta. Replica e marca a galera.",
      clip: 9,
      views: 33400,
      likes: 210,
    },
    {
      id: "v-cook-2",
      user: "seed:cozinha",
      caption: "Pão na chapa com manteiga até dourar. Café junto. Fim.",
      clip: 3,
      views: 91002,
      likes: 13200,
    },
    {
      id: "v-rules",
      user: officialId,
      caption:
        "Como denunciar um vídeo: toque em Denunciar, escolha o motivo, a gente analisa. A ONDA não é terra de ninguém.",
      clip: 8,
      sound: "ONDA · diretrizes",
      views: 44020,
      likes: 6201,
    },
  ];

  for (const v of videos) {
    const s = clip(v.clip);
    await sql`
      insert into videos (
        id, user_id, caption, video_url, sound_name, view_count, restricted, removed
      ) values (
        ${v.id}, ${v.user}, ${v.caption}, ${s.url},
        ${v.sound ?? s.sound}, ${v.views}, ${false}, ${false}
      )
      on conflict (id) do nothing
    `;

    const likers = ["seed:luna", "seed:cafe", "seed:rio", "seed:neon", "seed:mar"];
    const likeN = Math.min(likers.length, Math.max(1, Math.floor(v.likes / 4000)));
    for (let i = 0; i < likeN; i++) {
      const uid = likers[i]!;
      if (uid === v.user) continue;
      await sql`
        insert into likes (user_id, video_id) values (${uid}, ${v.id})
        on conflict do nothing
      `;
    }
  }

  await sql`
    insert into comments (id, video_id, user_id, body) values
      (${nid()}, ${"v-welcome"}, ${"seed:luna"}, ${"Finalmente um app que parece nosso."}),
      (${nid()}, ${"v-welcome"}, ${"seed:rio"}, ${"A onda chegou."}),
      (${nid()}, ${"v-luna-1"}, ${"seed:neon"}, ${"Essa transição no 0:07 matou."}),
      (${nid()}, ${"v-cook-1"}, ${"seed:cafe"}, ${"Fiz aqui. Ficou honesto."}),
      (${nid()}, ${"v-rio-1"}, ${"seed:mar"}, ${"Levou o sábado inteiro."})
    on conflict do nothing
  `;

  await sql`
    insert into follows (follower_id, following_id) values
      (${"seed:luna"}, ${officialId}),
      (${"seed:cafe"}, ${officialId}),
      (${"seed:rio"}, ${"seed:luna"}),
      (${"seed:neon"}, ${"seed:luna"}),
      (${"seed:mar"}, ${"seed:rio"}),
      (${"seed:skate"}, ${"seed:luna"}),
      (${"seed:cozinha"}, ${officialId})
    on conflict do nothing
  `;

  await sql`
    insert into reports (id, video_id, reporter_id, reason, details, status) values
      (
        ${"r-spam"}, ${"v-spam-1"}, ${"seed:luna"}, ${"spam"},
        ${"Promessa de dinheiro fácil e chamada agressiva na legenda."}, ${"open"}
      ),
      (
        ${"r-danger"}, ${"v-danger-1"}, ${"seed:rio"}, ${"dangerous"},
        ${"Incentiva salto perigoso e desafio a outras pessoas."}, ${"open"}
      ),
      (
        ${"r-false"}, ${"v-cook-1"}, ${"seed:click"}, ${"hate"},
        ${"Não gostei da receita."}, ${"open"}
      ),
      (
        ${"r-cook2"}, ${"v-cook-2"}, ${"seed:neon"}, ${"other"},
        ${"Só testando o botão de denúncia? Não — achei a thumbnail estranha."}, ${"open"}
      )
    on conflict (id) do nothing
  `;

  await sql`
    insert into seed_meta (key, value) values (${SEED_KEY}, ${"1"})
    on conflict (key) do nothing
  `;
}

async function ensureOfficialUser(): Promise<string> {
  const sql = await getSql();
  const found = await sql<{ id: string }>`
    select id from "user" where email = ${OFFICIAL_EMAIL} limit 1
  `;
  if (found[0]?.id) return found[0].id;

  try {
    const { auth } = await import("@/lib/auth/server");
    const result = await auth.api.signUpEmail({
      body: {
        name: OFFICIAL_DISPLAY,
        email: OFFICIAL_EMAIL,
        password: OFFICIAL_PASSWORD,
      },
    });
    const id = result.user?.id;
    if (id) return id;
  } catch {
    const again = await sql<{ id: string }>`
      select id from "user" where email = ${OFFICIAL_EMAIL} limit 1
    `;
    if (again[0]?.id) return again[0].id;
  }

  return "seed-official";
}
