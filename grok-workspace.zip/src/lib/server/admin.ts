import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import type { ModerationLog, ReportDetail } from "@/lib/onda/types";
import { nid } from "@/lib/utils";
import { asIso, asStr, mapAiReview, VIDEO_SELECT, mapVideo } from "./map";
import { loadProfileByUserId, requireAdmin } from "./profiles";
import { ensureSeeded } from "./seed";

async function notify(
  userId: string,
  kind: string,
  title: string,
  body: string,
  href: string | null,
) {
  const sql = await getSql();
  await sql`
    insert into notifications (id, user_id, kind, title, body, href)
    values (${nid()}, ${userId}, ${kind}, ${title}, ${body}, ${href})
  `;
}

async function logAction(
  adminId: string,
  action: string,
  opts: { targetUserId?: string; videoId?: string; reportId?: string; note?: string },
) {
  const sql = await getSql();
  await sql`
    insert into moderation_actions (
      id, admin_id, target_user_id, video_id, report_id, action, note
    ) values (
      ${nid()}, ${adminId}, ${opts.targetUserId ?? null}, ${opts.videoId ?? null},
      ${opts.reportId ?? null}, ${action}, ${opts.note ?? ""}
    )
  `;
}

export const listReports = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((status?: string) => status ?? "open")
  .handler(async ({ context, data: status }) => {
    await requireAdmin(context.userId);
    await ensureSeeded();
    const sql = await getSql();
    const filter = status === "all" ? null : status;
    const rows = await sql.query<{
      id: string;
      video_id: string;
      reporter_id: string;
      reason: string;
      details: string;
      status: string;
      created_at: unknown;
      caption: string;
      handle: string;
      display_name: string;
      reporter_handle: string;
      has_ai: boolean;
    }>(
      `select r.id, r.video_id, r.reporter_id, r.reason, r.details, r.status, r.created_at,
              v.caption, p.handle, p.display_name,
              rp.handle as reporter_handle,
              exists(select 1 from ai_reviews a where a.report_id = r.id) as has_ai
       from reports r
       join videos v on v.id = r.video_id
       join profiles p on p.user_id = v.user_id
       join profiles rp on rp.user_id = r.reporter_id
       where ($1::text is null or r.status = $1)
       order by r.created_at desc
       limit 80`,
      [filter],
    );
    return rows.map((r) => ({
      id: r.id,
      videoId: r.video_id,
      reporterId: r.reporter_id,
      reason: r.reason,
      details: r.details,
      status: r.status,
      createdAt: asIso(r.created_at),
      caption: r.caption,
      handle: r.handle,
      displayName: r.display_name,
      reporterHandle: r.reporter_handle,
      hasAi: Boolean(r.has_ai),
    }));
  });

export const getReportDetail = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((id: string) => id)
  .handler(async ({ context, data: id }): Promise<ReportDetail | null> => {
    await requireAdmin(context.userId);
    await ensureSeeded();
    const sql = await getSql();
    const reports = await sql`
      select r.id, r.video_id, r.reporter_id, r.reason, r.details, r.status, r.created_at,
             rp.handle as reporter_handle, rp.display_name as reporter_name
      from reports r
      join profiles rp on rp.user_id = r.reporter_id
      where r.id = ${id}
      limit 1
    `;
    const report = reports[0];
    if (!report) return null;

    const vrows = await sql.query<Parameters<typeof mapVideo>[0]>(
      `select ${VIDEO_SELECT}
       from videos v
       join profiles p on p.user_id = v.user_id
       where v.id = $1
       limit 1`,
      [report.video_id],
    );
    const videoRow = vrows[0];
    if (!videoRow) return null;

    const aiRows = await sql`
      select * from ai_reviews where report_id = ${id} limit 1
    `;

    return {
      id: asStr(report.id),
      videoId: asStr(report.video_id),
      reporterId: asStr(report.reporter_id),
      reason: asStr(report.reason),
      details: asStr(report.details),
      status: asStr(report.status) as ReportDetail["status"],
      createdAt: asIso(report.created_at),
      reporterHandle: asStr(report.reporter_handle),
      reporterName: asStr(report.reporter_name),
      video: mapVideo(videoRow, false),
      aiReview: aiRows[0] ? mapAiReview(aiRows[0]) : null,
    };
  });

export const listAdminUsers = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .validator((q?: string) => (q ?? "").trim().slice(0, 60))
  .handler(async ({ context, data: q }) => {
    await requireAdmin(context.userId);
    const sql = await getSql();
    const like = q ? `%${q.toLowerCase()}%` : "%";
    const rows = await sql.query<{
      user_id: string;
      handle: string;
      display_name: string;
      verified: boolean;
      is_official: boolean;
      is_admin: boolean;
      restricted: boolean;
      warning_count: number;
      avatar_hue: number;
    }>(
      `select user_id, handle, display_name, verified, is_official, is_admin,
              restricted, warning_count, avatar_hue
       from profiles
       where lower(handle) like $1 or lower(display_name) like $1
       order by is_official desc, verified desc, handle
       limit 40`,
      [like],
    );
    return rows.map((r) => ({
      userId: r.user_id,
      handle: r.handle,
      displayName: r.display_name,
      verified: Boolean(r.verified),
      isOfficial: Boolean(r.is_official),
      isAdmin: Boolean(r.is_admin),
      restricted: Boolean(r.restricted),
      warningCount: Number(r.warning_count) || 0,
      avatarHue: Number(r.avatar_hue) || 168,
    }));
  });

export const listModerationLog = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    const sql = await getSql();
    const rows = await sql`
      select id, action, note, target_user_id, video_id, report_id, created_at
      from moderation_actions
      order by created_at desc
      limit 40
    `;
    return rows.map(
      (r): ModerationLog => ({
        id: asStr(r.id),
        action: asStr(r.action),
        note: asStr(r.note),
        targetUserId: r.target_user_id ? asStr(r.target_user_id) : null,
        videoId: r.video_id ? asStr(r.video_id) : null,
        reportId: r.report_id ? asStr(r.report_id) : null,
        createdAt: asIso(r.created_at),
      }),
    );
  });

export const adminStats = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await requireAdmin(context.userId);
    await ensureSeeded();
    const sql = await getSql();
    const [videos] = await sql<{ n: number }>`select count(*)::int as n from videos where removed = false`;
    const [users] = await sql<{ n: number }>`select count(*)::int as n from profiles`;
    const [open] = await sql<{ n: number }>`select count(*)::int as n from reports where status = 'open'`;
    const [restricted] = await sql<{ n: number }>`select count(*)::int as n from videos where restricted = true`;
    return {
      videos: Number(videos?.n) || 0,
      users: Number(users?.n) || 0,
      openReports: Number(open?.n) || 0,
      restrictedVideos: Number(restricted?.n) || 0,
    };
  });

type ModerateInput = {
  action:
    | "verify"
    | "unverify"
    | "warn"
    | "restrict_user"
    | "unrestrict_user"
    | "restrict_video"
    | "unrestrict_video"
    | "remove_video"
    | "restore_video"
    | "dismiss_report"
    | "action_report";
  targetUserId?: string;
  videoId?: string;
  reportId?: string;
  note?: string;
};

export const moderate = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: ModerateInput) => input)
  .handler(async ({ context, data }) => {
    const admin = await requireAdmin(context.userId);
    const sql = await getSql();
    const note = (data.note ?? "").slice(0, 300);

    switch (data.action) {
      case "verify":
      case "unverify": {
        if (!data.targetUserId) throw new Error("Usuário obrigatório");
        const on = data.action === "verify";
        await sql`update profiles set verified = ${on} where user_id = ${data.targetUserId}`;
        const target = await loadProfileByUserId(data.targetUserId);
        if (target) {
          await notify(
            data.targetUserId,
            "verify",
            on ? "Sua conta foi verificada" : "O selo verificado foi removido",
            on
              ? "A conta oficial da ONDA confirmou a autenticidade do seu perfil."
              : "Seu selo de verificação foi retirado.",
            `/u/${target.handle}`,
          );
        }
        break;
      }
      case "warn": {
        if (!data.targetUserId) throw new Error("Usuário obrigatório");
        await sql`
          update profiles
          set warning_count = warning_count + 1
          where user_id = ${data.targetUserId}
        `;
        const target = await loadProfileByUserId(data.targetUserId);
        const count = (target?.warningCount ?? 0) + 1;
        if (count >= 3) {
          await sql`update profiles set restricted = true where user_id = ${data.targetUserId}`;
        }
        if (target) {
          await notify(
            data.targetUserId,
            "warning",
            `Aviso da moderação (${count}/3)`,
            note ||
              "Sua conta recebeu um aviso por possível violação das diretrizes. No terceiro aviso a conta é restrita.",
            "/diretrizes",
          );
        }
        break;
      }
      case "restrict_user":
      case "unrestrict_user": {
        if (!data.targetUserId) throw new Error("Usuário obrigatório");
        const on = data.action === "restrict_user";
        await sql`update profiles set restricted = ${on} where user_id = ${data.targetUserId}`;
        const target = await loadProfileByUserId(data.targetUserId);
        if (target) {
          await notify(
            data.targetUserId,
            "restrict",
            on ? "Sua conta foi restrita" : "Sua conta foi liberada",
            on
              ? "Você não pode publicar até a restrição ser removida."
              : "Você já pode publicar de novo.",
            `/u/${target.handle}`,
          );
        }
        break;
      }
      case "restrict_video":
      case "unrestrict_video":
      case "remove_video":
      case "restore_video": {
        if (!data.videoId) throw new Error("Vídeo obrigatório");
        if (data.action === "restrict_video") {
          await sql`update videos set restricted = true where id = ${data.videoId}`;
        } else if (data.action === "unrestrict_video") {
          await sql`update videos set restricted = false where id = ${data.videoId}`;
        } else if (data.action === "remove_video") {
          await sql`update videos set removed = true, restricted = true where id = ${data.videoId}`;
        } else {
          await sql`update videos set removed = false, restricted = false where id = ${data.videoId}`;
        }
        const owner = await sql<{ user_id: string }>`
          select user_id from videos where id = ${data.videoId} limit 1
        `;
        if (owner[0]) {
          await notify(
            owner[0].user_id,
            "video",
            data.action === "remove_video"
              ? "Um vídeo seu foi removido"
              : data.action === "restrict_video"
                ? "Um vídeo seu foi restrito"
                : "Um vídeo seu foi restaurado",
            note || "A moderação da ONDA revisou o conteúdo.",
            `/v/${data.videoId}`,
          );
        }
        break;
      }
      case "dismiss_report":
      case "action_report": {
        if (!data.reportId) throw new Error("Denúncia obrigatória");
        const status = data.action === "dismiss_report" ? "dismissed" : "actioned";
        await sql`update reports set status = ${status} where id = ${data.reportId}`;
        break;
      }
      default:
        throw new Error("Ação inválida");
    }

    await logAction(admin.userId, data.action, {
      targetUserId: data.targetUserId,
      videoId: data.videoId,
      reportId: data.reportId,
      note,
    });
    return { ok: true as const };
  });
