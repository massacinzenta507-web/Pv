import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import { REPORT_REASONS } from "@/lib/onda/guidelines";
import { nid } from "@/lib/utils";
import { ensureSeeded } from "./seed";

export const reportVideo = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { videoId: string; reason: string; details?: string }) => ({
    videoId: input.videoId,
    reason: input.reason,
    details: (input.details ?? "").trim().slice(0, 400),
  }))
  .handler(async ({ context, data }) => {
    await ensureSeeded();
    const valid = REPORT_REASONS.some((r) => r.id === data.reason);
    if (!valid) throw new Error("Motivo inválido");
    const sql = await getSql();
    const video = await sql<{ id: string; user_id: string }>`
      select id, user_id from videos where id = ${data.videoId} limit 1
    `;
    if (!video[0]) throw new Error("Vídeo não encontrado");
    if (video[0].user_id === context.userId) {
      throw new Error("Você não pode denunciar o próprio vídeo");
    }
    const dup = await sql<{ id: string }>`
      select id from reports
      where video_id = ${data.videoId}
        and reporter_id = ${context.userId}
        and status in ('open', 'reviewing')
      limit 1
    `;
    if (dup[0]) return { ok: true as const, already: true };

    await sql`
      insert into reports (id, video_id, reporter_id, reason, details, status)
      values (${nid()}, ${data.videoId}, ${context.userId}, ${data.reason}, ${data.details}, ${"open"})
    `;
    return { ok: true as const, already: false };
  });
