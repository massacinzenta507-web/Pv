import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import { OFFICIAL_EMAIL, OFFICIAL_HANDLE } from "@/lib/onda/official";
import type { Profile } from "@/lib/onda/types";
import { ensureSeeded } from "./seed";
import { mapProfile } from "./map";

const PROFILE_SELECT = `
  p.user_id, p.handle, p.display_name, p.bio, p.avatar_hue, p.avatar_url,
  p.verified, p.is_official, p.is_admin, p.restricted, p.warning_count, p.created_at,
  (select count(*)::int from follows f where f.following_id = p.user_id) as follower_count,
  (select count(*)::int from follows f where f.follower_id = p.user_id) as following_count,
  (select count(*)::int from videos v where v.user_id = p.user_id and v.removed = false) as video_count
`;

export async function loadProfileByUserId(userId: string): Promise<Profile | null> {
  const sql = await getSql();
  const rows = await sql.query<Parameters<typeof mapProfile>[0]>(
    `select ${PROFILE_SELECT} from profiles p where p.user_id = $1 limit 1`,
    [userId],
  );
  return rows[0] ? mapProfile(rows[0]) : null;
}

export async function loadProfileByHandle(handle: string): Promise<Profile | null> {
  const sql = await getSql();
  const rows = await sql.query<Parameters<typeof mapProfile>[0]>(
    `select ${PROFILE_SELECT} from profiles p where lower(p.handle) = lower($1) limit 1`,
    [handle],
  );
  return rows[0] ? mapProfile(rows[0]) : null;
}

function slugify(name: string): string {
  const base = name
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLowerCase()
    .replace(/[^a-z0-9]+/g, ".")
    .replace(/^\.|\.$/g, "")
    .slice(0, 18);
  return base || "onda";
}

async function authUserMeta(userId: string): Promise<{
  name: string | null;
  email: string | null;
  image: string | null;
}> {
  const sql = await getSql();
  const rows = await sql<{ name: string; email: string; image: string | null }>`
    select name, email, image from "user" where id = ${userId} limit 1
  `;
  const u = rows[0];
  return {
    name: u?.name ?? null,
    email: u?.email ?? null,
    image: u?.image ?? null,
  };
}

export async function ensureProfileFor(
  userId: string,
  name: string | null,
  email: string | null,
  image: string | null,
): Promise<Profile> {
  await ensureSeeded();
  const existing = await loadProfileByUserId(userId);
  if (existing) {
    if (image && !existing.avatarUrl) {
      const sql = await getSql();
      await sql`update profiles set avatar_url = ${image} where user_id = ${userId}`;
      return { ...existing, avatarUrl: image };
    }
    return existing;
  }

  const sql = await getSql();
  const isOfficial = (email ?? "").toLowerCase() === OFFICIAL_EMAIL;
  let handle = isOfficial ? OFFICIAL_HANDLE : slugify(name || email?.split("@")[0] || "onda");
  if (!isOfficial) {
    let n = 0;
    while (true) {
      const candidate = n === 0 ? handle : `${handle}${n}`;
      const clash = await sql<{ user_id: string }>`
        select user_id from profiles where handle = ${candidate} limit 1
      `;
      if (!clash[0]) {
        handle = candidate;
        break;
      }
      n += 1;
      if (n > 40) {
        handle = `onda.${userId.slice(0, 6)}`;
        break;
      }
    }
  }

  const display = isOfficial ? "ONDA" : name?.trim() || handle;
  const hue = 140 + (userId.charCodeAt(0) % 80);

  await sql`
    insert into profiles (
      user_id, handle, display_name, bio, avatar_hue, avatar_url,
      verified, is_official, is_admin
    ) values (
      ${userId}, ${handle}, ${display}, ${isOfficial ? "Conta oficial da ONDA." : ""},
      ${hue}, ${image}, ${isOfficial}, ${isOfficial}, ${isOfficial}
    )
    on conflict (user_id) do nothing
  `;

  const created = await loadProfileByUserId(userId);
  if (!created) throw new Error("Não foi possível criar o perfil");
  return created;
}

export const getMe = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await ensureSeeded();
    const meta = await authUserMeta(context.userId);
    return ensureProfileFor(context.userId, meta.name, meta.email, meta.image);
  });

export const getProfile = createServerFn({ method: "GET" })
  .validator((handle: string) => handle.trim())
  .handler(async ({ data: handle }) => {
    await ensureSeeded();
    if (!handle) return null;
    return loadProfileByHandle(handle);
  });

export const searchProfiles = createServerFn({ method: "GET" })
  .validator((q: string) => q.trim().slice(0, 60))
  .handler(async ({ data: q }) => {
    await ensureSeeded();
    if (!q) return [] as Profile[];
    const sql = await getSql();
    const like = `%${q.toLowerCase()}%`;
    const rows = await sql.query<Parameters<typeof mapProfile>[0]>(
      `select ${PROFILE_SELECT} from profiles p
       where lower(p.handle) like $1 or lower(p.display_name) like $1
       order by p.verified desc, p.handle
       limit 20`,
      [like],
    );
    return rows.map(mapProfile);
  });

export const updateBio = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((bio: string) => bio.slice(0, 160))
  .handler(async ({ context, data: bio }) => {
    const sql = await getSql();
    await sql`update profiles set bio = ${bio} where user_id = ${context.userId}`;
    return loadProfileByUserId(context.userId);
  });

export async function requireAdmin(userId: string): Promise<Profile> {
  await ensureSeeded();
  const meta = await authUserMeta(userId);
  const profile = await ensureProfileFor(userId, meta.name, meta.email, meta.image);
  if (!profile.isAdmin) {
    const err = Object.assign(new Error("Forbidden"), { status: 403 });
    throw err;
  }
  return profile;
}
