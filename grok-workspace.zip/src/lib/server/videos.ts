import { createServerFn } from "@tanstack/react-start";
import { authMiddleware } from "@/lib/auth/middleware";
import { getSql } from "@/lib/db";
import { STOCK_CLIPS } from "@/lib/onda/stock";
import type { VideoCard } from "@/lib/onda/types";
import { nid } from "@/lib/utils";
import { VIDEO_SELECT, mapVideo } from "./map";
import { getMe, loadProfileByUserId } from "./profiles";
import { ensureSeeded } from "./seed";

async function likedSet(userId: string | null): Promise<Set<string>> {
  if (!userId) return new Set();
  const sql = await getSql();
  const rows = await sql<{ video_id: string }>`
    select video_id from likes where user_id = ${userId}
  `;
  return new Set(rows.map((r) => r.video_id));
}

async function fetchVideos(
  whereSql: string,
  params: unknown[],
  viewerId: string | null,
): Promise<VideoCard[]> {
  const sql = await getSql();
  const rows = await sql.query<Parameters<typeof mapVideo>[0]>(
    `select ${VIDEO_SELECT}
     from videos v
     join profiles p on p.user_id = v.user_id
     ${whereSql}`,
    params,
  );
  const liked = await likedSet(viewerId);
  return rows.map((r) => mapVideo(r, liked.has(String(r.id))));
}

export const listForYou = createServerFn({ method: "GET" }).handler(async () => {
  await ensureSeeded();
  return fetchVideos(
    `where v.removed = false and v.restricted = false
     order by v.created_at desc
     limit 40`,
    [],
    null,
  );
});

export const listFollowing = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await ensureSeeded();
    return fetchVideos(
      `where v.removed = false and v.restricted = false
         and v.user_id in (select following_id from follows where follower_id = $1)
       order by v.created_at desc
       limit 40`,
      [context.userId],
      context.userId,
    );
  });

export const listUserVideos = createServerFn({ method: "GET" })
  .validator((input: { handle: string; includeHidden?: boolean }) => input)
  .handler(async ({ data }) => {
    await ensureSeeded();
    return fetchVideos(
      `where lower(p.handle) = lower($1)
         and v.removed = false
         and ($2::boolean = true or v.restricted = false)
       order by v.created_at desc
       limit 60`,
      [data.handle, Boolean(data.includeHidden)],
      null,
    );
  });

export const getVideo = createServerFn({ method: "GET" })
  .validator((id: string) => id)
  .handler(async ({ data: id }) => {
    await ensureSeeded();
    const videos = await fetchVideos(`where v.id = $1 limit 1`, [id], null);
    return videos[0] ?? null;
  });

export const hydrateMine = createServerFn({ method: "GET" })
  .middleware([authMiddleware])
  .handler(async ({ context }) => {
    await ensureSeeded();
    const me = await getMe();
    const sql = await getSql();
    const likes = await sql<{ video_id: string }>`
      select video_id from likes where user_id = ${context.userId}
    `;
    const following = await sql<{ following_id: string }>`
      select following_id from follows where follower_id = ${context.userId}
    `;
    return {
      me,
      likedIds: likes.map((r) => r.video_id),
      followingIds: following.map((r) => r.following_id),
    };
  });

export const publishVideo = createServerFn({ method: "POST" })
  .middleware([authMiddleware])
  .validator((input: { caption: string; videoUrl: string; soundName?: string }) => ({
    caption: input.caption.trim().slice(0, 220),
    videoUrl: input.videoUrl.trim().slice(0, 500),
    soundName: (input.soundName ?? "Som original").trim().slice(0, 80),
  }))
  .handler(async ({ context, data }) => {
    await ensureSeeded();
    const me = await loadProfileByUserId(context.userId);
    if (!me) throw new Error("Crie seu perfil antes de publicar");
    if (me.restricted) throw new Error("Sua conta está restrita e não pode publicar agora");
    if (!data.videoUrl) throw new Error("Escolha um clipe");
    const allowed = STOCK_CLIPS.some((c) => c.url === data.videoUrl);
    const http = /^https:\/\//i.test(data.videoUrl);
    if (!allowed && !http) throw new Error("URL de vídeo inválida");
    const sql = await getSql();
    const id = nid();
    await sql`
      insert into videos (id, user_id, caption, video_url, sound_name)
      values (${id}, ${context.userId}, ${data.caption}, ${data.videoUrl}, ${data.soundName})
    `;
    const videos = await fetchVideos(`where v.id = $1 limit 1`, [id], context.userId);
    return videos[0]!;
  });

export const bumpView = createServerFn({ method: "POST" })
  .validator((id: string) => id)
  .handler(async ({ data: id }) => {
    const sql = await getSql();
    await sql`update videos set view_count = view_count + 1 where id = ${id}`;
    return true;
  });
