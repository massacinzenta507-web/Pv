import * as React from "react";
import { cn } from "@/lib/utils";

export function Textarea({ className, ...props }: React.ComponentProps<"textarea">) {
  return (
    <textarea
      className={cn(
        "flex min-h-24 w-full rounded-lg bg-elevated px-3 py-2.5 text-sm text-fg shadow-[0_0_0_1px_rgb(255_255_255_/_0.1)] placeholder:text-subtle outline-none transition-[box-shadow] duration-150 focus-visible:shadow-[0_0_0_2px_var(--color-accent)] disabled:opacity-40",
        className,
      )}
      {...props}
    />
  );
}
