-- ONDA short-video platform schema

create table if not exists profiles (
  user_id       text primary key,
  handle        text not null unique,
  display_name  text not null,
  bio           text not null default '',
  avatar_hue    integer not null default 168,
  avatar_url    text,
  verified      boolean not null default false,
  is_official   boolean not null default false,
  is_admin      boolean not null default false,
  restricted    boolean not null default false,
  warning_count integer not null default 0,
  created_at    timestamptz not null default now()
);
create index if not exists profiles_handle_idx on profiles (handle);

create table if not exists videos (
  id          text primary key,
  user_id     text not null,
  caption     text not null default '',
  video_url   text not null,
  poster_url  text,
  sound_name  text not null default 'Som original',
  restricted  boolean not null default false,
  removed     boolean not null default false,
  view_count  integer not null default 0,
  created_at  timestamptz not null default now()
);
create index if not exists videos_user_id_idx on videos (user_id);
create index if not exists videos_created_at_idx on videos (created_at desc);

create table if not exists follows (
  follower_id  text not null,
  following_id text not null,
  created_at   timestamptz not null default now(),
  primary key (follower_id, following_id)
);
create index if not exists follows_following_id_idx on follows (following_id);

create table if not exists likes (
  user_id    text not null,
  video_id   text not null,
  created_at timestamptz not null default now(),
  primary key (user_id, video_id)
);
create index if not exists likes_video_id_idx on likes (video_id);

create table if not exists comments (
  id         text primary key,
  video_id   text not null,
  user_id    text not null,
  body       text not null,
  created_at timestamptz not null default now()
);
create index if not exists comments_video_id_idx on comments (video_id, created_at);

create table if not exists reports (
  id          text primary key,
  video_id    text not null,
  reporter_id text not null,
  reason      text not null,
  details     text not null default '',
  status      text not null default 'open',
  created_at  timestamptz not null default now()
);
create index if not exists reports_status_idx on reports (status, created_at desc);
create index if not exists reports_video_id_idx on reports (video_id);

create table if not exists ai_reviews (
  id              text primary key,
  report_id       text not null unique,
  video_id        text not null,
  verdict         text not null,
  summary         text not null,
  guidelines_hit  text not null default '[]',
  recommended     text not null default 'dismiss',
  confidence      text not null default '0',
  created_at      timestamptz not null default now()
);

create table if not exists moderation_actions (
  id             text primary key,
  admin_id       text not null,
  target_user_id text,
  video_id       text,
  report_id      text,
  action         text not null,
  note           text not null default '',
  created_at     timestamptz not null default now()
);
create index if not exists moderation_actions_target_idx on moderation_actions (target_user_id, created_at desc);

create table if not exists notifications (
  id         text primary key,
  user_id    text not null,
  kind       text not null,
  title      text not null,
  body       text not null default '',
  href       text,
  read       boolean not null default false,
  created_at timestamptz not null default now()
);
create index if not exists notifications_user_id_idx on notifications (user_id, created_at desc);

create table if not exists seed_meta (
  key   text primary key,
  value text not null
);
